package com.phoenix;

import java.util.Scanner;

/**
 * Converted from ShittyMinesweeper by Phoenix Boisnier
 * @author Phoenix Boisnier
 */
public class MineSweeper {

    public static void main(String[] args) {

        int size;
        int mines;
        Scanner scone = new Scanner(System.in);

        System.out.println("Input size (Between 5 and 20):");
        size = Integer.parseInt(scone.nextLine());
        while(size < 5 || size > 20){
            System.out.println("Size not within limits, try again. Input size (Between 5 and 20):");
            try{
                size = Integer.parseInt(scone.nextLine());
            }
            catch(IllegalArgumentException e){
                System.out.println("Input must be a number.");
            }
        }
        System.out.println("Input number of mines (less than grid area):");
        mines = Integer.parseInt(scone.nextLine());
        while(mines>(size*size)||mines < 1){
            if(mines < 1) System.out.println("Too few mines. Are you trying to cheat?");
            else System.out.println("Too many mines. Input number of mines (less than grid size):");
            try{
                mines = Integer.parseInt(scone.nextLine());
            }
            catch(IllegalArgumentException e){
                System.out.println("Input must be a number.");
            }
        }
        System.out.println("Building map...");

        MinesweeperControlModel control = new MinesweeperControlModel(size, mines);

        int x;
        int y;
        System.out.println("Building display...");

        control.showShown();
        String input;

//-------------------------------------------------------------------------------------------------------------------
        /*
         * This is the main loop that runs the game.
         */
        System.out.println("Mines placed: "+ control.getMineTotal());
        do {
            x = -1;
            y = -1;
            System.out.println("Pick an x coordinate:");
            while (y < 0) {
                try {
                    y = Integer.parseInt(scone.nextLine());
                } catch (IllegalArgumentException e) {
                    System.out.println("Input must be a number.");
                }
            }
            System.out.println("Pick a  y coordinate:");
            while (x < 0) {
                try {
                    x = Integer.parseInt(scone.nextLine());
                } catch (IllegalArgumentException e) {
                    System.out.println("Input must be a number.");
                }
            }
            System.out.println("Select an action (R, reveal; F, flag):");
            input = scone.next();
            if (input.toUpperCase().equals("R")) {
                control.revealSquare(x, y);
            }
            if (input.toUpperCase().equals("F")) {
                //TODO
            }
            if (input.equals("show")){
                control.showMap(control.getMap());
            }
            else{
                control.showShown();
            }
            scone.nextLine();
        } while (control.getMineCount() != 0);
        scone.close();
    }
}
