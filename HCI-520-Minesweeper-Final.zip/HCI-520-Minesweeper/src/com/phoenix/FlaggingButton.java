package com.phoenix;

import com.sun.tools.javac.Main;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.io.IOException;
import java.util.Objects;

public class FlaggingButton extends JButton {

    private boolean flagged = false;
    private final ImageIcon emptyIcon;
    private final ImageIcon flagdIcon;
    private final JLabel revealed;

    /**
     * Creates a new FlaggingButton and sets its icon to the empty icon.
     * @throws IOException Can't find the image.
     */
    public FlaggingButton(char type) throws IOException {
        emptyIcon = new ImageIcon();
        flagdIcon = new ImageIcon(ImageIO.read(Objects.requireNonNull(
                Main.class.getClassLoader().getResource("flagdIcon2.png"))));
        revealed = new JLabel(loadImage(type));
        revealed.setLocation(this.getLocation());
        revealed.setVisible(false);
        this.setIcon(emptyIcon);
    }

    /**
     * Toggles the flag state and repaints the button.
     */
    public void toggleFlag(){
        flagged = !flagged;
        if(flagged) this.setIcon(flagdIcon);
        else this.setIcon(emptyIcon);
    }

    /**
     * Returns the flag state.
     * @return true or false
     */
    public boolean isFlagged(){
        return flagged;
    }

    /**
     * Gives the image under the button.
     * @return The image.
     */
    public JLabel getRevealedIcon(){
        revealed.setVisible(true);
        revealed.setLocation(this.getX()+7, this.getY()+7);
        return revealed;
    }

    /**
     * Picks the image to load in.
     * @param iconType char from the constructor
     * @return ImageIcon for the JLabel
     * @throws IOException can't find image
     */
    private ImageIcon loadImage(char iconType) throws IOException {
        ImageIcon revealed;
        if(iconType=='M'){
            revealed = new ImageIcon(ImageIO.read(Objects.requireNonNull(
                    Main.class.getClassLoader().getResource("mineIcon.jpeg"))));
        }
        else if(iconType=='0'){
            revealed = new ImageIcon(ImageIO.read(Objects.requireNonNull(
                    Main.class.getClassLoader().getResource("emptyIcon.png"))));
        }
        else{
            switch(iconType){
                case '1': {
                    revealed = new ImageIcon(ImageIO.read(Objects.requireNonNull(
                            Main.class.getClassLoader().getResource("oneIcon.png"))));
                    break;
                }
                case '2':{
                    revealed = new ImageIcon(ImageIO.read(Objects.requireNonNull(
                            Main.class.getClassLoader().getResource("twoIcon.png"))));
                    break;
                }
                case '3':{
                    revealed = new ImageIcon(ImageIO.read(Objects.requireNonNull(
                            Main.class.getClassLoader().getResource("threeIcon.png"))));
                    break;
                }
                case '4':{
                    revealed = new ImageIcon(ImageIO.read(Objects.requireNonNull(
                            Main.class.getClassLoader().getResource("fourIcon.png"))));
                    break;
                }
                case '5':{
                    revealed = new ImageIcon(ImageIO.read(Objects.requireNonNull(
                            Main.class.getClassLoader().getResource("fiveIcon.png"))));
                    break;
                }
                case '6':{
                    revealed = new ImageIcon(ImageIO.read(Objects.requireNonNull(
                            Main.class.getClassLoader().getResource("sixIcon.png"))));
                    break;
                }
                case '7':{
                    revealed = new ImageIcon(ImageIO.read(Objects.requireNonNull(
                            Main.class.getClassLoader().getResource("sevenIcon.png"))));
                    break;
                }
                case '8':{
                    revealed = new ImageIcon(ImageIO.read(Objects.requireNonNull(
                            Main.class.getClassLoader().getResource("eightIcon.png"))));
                    break;
                }
                default:{
                    revealed = new ImageIcon(ImageIO.read(Objects.requireNonNull(
                            Main.class.getClassLoader().getResource("errorIcon.png"))));
                    break;
                }
            }
        }
        return revealed;
    }

}
