package com.phoenix;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;

public class HomeWindow extends JFrame{

    public HomeWindow(){
        this.setTitle("Mine Swiffer");
        this.setSize(400, 500);
        this.setResizable(false);

        //TODO make this panel prettier.
        JPanel p = new JPanel();
        p.setLayout(new GridBagLayout());

        JButton startNewButton = new JButton("New Game");
        startNewButton.addActionListener(actionEvent -> {
            this.add(new NewGameWindow(p));
            p.setVisible(false);
        });
        startNewButton.setPreferredSize(new Dimension(200, 50));
        startNewButton.setMnemonic(KeyEvent.VK_N);

        JButton howToPlayButton = new JButton("How To Play");
        howToPlayButton.addActionListener(actionEvent -> new HowToPlay());
        howToPlayButton.setPreferredSize(new Dimension(200, 25));
        howToPlayButton.setMnemonic(KeyEvent.VK_H);

        GridBagConstraints playConst = new GridBagConstraints();
        playConst.gridx = 0;
        playConst.gridy = 1;
        playConst.insets = new Insets(5,5,5,5);
        p.add(howToPlayButton, playConst);

        GridBagConstraints startConst = new GridBagConstraints();
        startConst.gridx = 0;
        startConst.gridy = 0;
        startConst.insets = new Insets(5,5,5,5);
        p.add(startNewButton);
        p.setVisible(true);

        this.add(p);
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        this.repaint();
        this.setVisible(true);
    }
}
