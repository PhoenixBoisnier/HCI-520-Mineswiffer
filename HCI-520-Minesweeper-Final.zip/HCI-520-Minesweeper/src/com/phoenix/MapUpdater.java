package com.phoenix;

import javax.swing.*;

public class MapUpdater extends SwingWorker<MinesweeperControlModel, Integer> {

    private final MinesweeperControlModel mcm;
    private final int x;
    private final int y;

    public MapUpdater(MinesweeperControlModel model, int tx, int ty){mcm = model; x = tx; y = ty;}

    @Override
    protected MinesweeperControlModel doInBackground() throws Exception {
        mcm.revealSquare(x, y);
        return mcm;
    }
}
