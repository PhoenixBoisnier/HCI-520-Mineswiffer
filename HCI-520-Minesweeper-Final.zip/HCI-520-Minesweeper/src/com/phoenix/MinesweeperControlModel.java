package com.phoenix;

/**
 * Converted from ShittyMinesweeper
 */
class MinesweeperControlModel {

    private int mineCount;
    private final char[][] map;
    private final boolean[][] shown;
    private final int mineTotal;

    /**
     * Creates a Minesweeper Control object. This keeps track of what is where on the map, and if it has been revealed.
     * @param size The size of the map.
     * @param mines The number of mines in the map.
     */
    public MinesweeperControlModel(int size , int mines) {

        mineTotal = mines;
        map = new char[size][size];
        shown = new boolean[size][size];
        int x;
        int y;
        //fills the map with 0's and sets shown to false.
        for (int q = 0; q < size; q++) {
            for (int a = 0; a < size; a++) {
                map[q][a] = '0';
                shown[q][a] = false;
            }
        }
        //places mines
        for (int q = 0; q < mines; q++) {
            x = (int) (Math.random() * size);
            y = (int) (Math.random() * size);
            while(map[x][y] == 'M'){
                x = (int) (Math.random() * size);
                y = (int) (Math.random() * size);
            }
            mineCount++;
            map[x][y] = 'M';
        }
        //places numbers
        for (int q = 0; q < size; q++) {
            for (int a = 0; a < size; a++) {
                if (map[q][a] != 'M') {
                    map[q][a] = this.markupMap(q, a);
                }
            }
        }
    }

    /**
     * Returns the number of mines still active.
     * @return Returns the number of active mines.
     */
    public int getMineCount() {
        return mineCount;
    }

    /**
     * Returns the total number of mines.
     * @return The total number of mines.
     */
    public int getMineTotal(){
        return mineTotal;
    }

    /**
     * Decreases the number of active mines.
     */
    public void decMineCount() {
        mineCount--;
    }

    /**
     * Increases the number of active mines.
     */
    public void incMineCount(){
        mineCount++;
    }

    /**
     * Returns the value under the location at x,y
     *
     * @param x X-coordinate
     * @param y Y-coordinate
     * @return M for mine, or an int between 0 and 8
     */
    public char revealSquare(int x, int y) {
        shown[x][y] = true;
        if(map[x][y]!='M' && map[x][y] == '0'){
            revealNeighbors(x,y);
        }
        return map[x][y];
    }

    /**
     * This method checks the value at the point.
     * @param x X-coordinate
     * @param y Y-coordinate
     * @return The value of the point on the map.
     */
    public char peekSquare(int x, int y){
        return map[x][y];
    }

    /**
     * Prints the grid to terminal.
     */
    public void showShown() {
        System.out.print("G  ");
        for (int q = 0; q < shown.length; q++) {
            System.out.print(q + "  ");
        }
        System.out.println();
        for (int q = 0; q < shown.length; q++) {
            System.out.print(q + "  ");
            for (int a = 0; a < shown.length; a++) {
                if(shown[q][a]){
                    System.out.print(map[q][a] + "  ");
                }
                else{
                    System.out.print("X  ");
                }
            }
            System.out.println();
        }
    }

    /**
     * Sets values in the map such that they are a number between 1 and 8,
     * corresponding to the number of mines next to the space.
     *
     * @param x X-coordinate
     * @param y Y-coordinate
     * @return The integer score as a character of how many mines are nearby.
     */
    private char markupMap(int x, int y) {
        int minesNearby = '0';
        for (char c : this.getNeighbors(x, y)) {
            if (c == 'M') {
                minesNearby++;
            }
        }
        return (char) minesNearby;
    }

    /**
     * Reveals the neighbors surrounding the location specified.
     *
     * @param x X-coordinate
     * @param y Y-coordinate
     */
    private void revealNeighbors(int x, int y) {
        char[] neighbors = this.getNeighbors(x, y);
        if (0 <= x && x < map.length && 0 <= y && y < map.length) {
            for (int q = 0; q < neighbors.length; q++) {
                if (q == 0) {
                    if(neighbors[q] != 'M' && neighbors[q] != 'N' && x-1 >= 0 && y-1 >= 0){
                        if(!shown[x-1][y-1]) this.revealSquare(x - 1, y - 1);
                    }
                }
                if (q == 1) {
                    if(neighbors[q] != 'M' && neighbors[q] != 'N' && x-1 >= 0) {
                        if(!shown[x-1][y]) this.revealSquare(x - 1, y);
                    }
                }
                if (q == 2) {
                    if(neighbors[q] != 'M' && neighbors[q] != 'N' && x-1 >= 0 && y+1 < map.length) {
                        if(!shown[x-1][y+1]) this.revealSquare(x - 1, y + 1);
                    }
                }
                if (q == 3) {
                    if(neighbors[q] != 'M' && neighbors[q] != 'N' && y+1 < map.length) {
                        if(!shown[x][y+1]) this.revealSquare(x, y + 1);
                    }
                }
                if (q == 4) {
                    if(neighbors[q] != 'M' && neighbors[q] != 'N' && x+1 < map.length && y+1 < map.length) {
                        if(!shown[x+1][y+1]) this.revealSquare(x + 1, y + 1);
                    }
                }
                if (q == 5) {
                    if(neighbors[q] != 'M' && neighbors[q] != 'N' && x+1 < map.length) {
                        if(!shown[x+1][y]) this.revealSquare(x + 1, y);
                    }
                }
                if (q == 6) {
                    if(neighbors[q] != 'M' && neighbors[q] != 'N' && x+1 < map.length && y-1 >= 0) {
                        if(!shown[x+1][y-1]) this.revealSquare(x + 1, y - 1);
                    }
                }
                if (q == 7) {
                    if(neighbors[q] != 'M' && neighbors[q] != 'N' && y+1 < map.length) {
                        if(!shown[x][y-1]) this.revealSquare(x, y - 1);
                    }
                }
            }
        }
    }

    /**
     * Returns the list of neighbors starting with 0,0 and going clockwise.
     * If a neighbor is not present, the value will be N.
     *
     * @param x X-coordinate
     * @param y Y-coordinate
     * @return values of neighboring spaces
     */
    private char[] getNeighbors(int x, int y) {
        char[] neighbors = new char[8];
        for (int q = 0; q < neighbors.length; q++) {
            if (q == 0) {
                try {
                    neighbors[q] = map[x - 1][y - 1];
                } catch (IndexOutOfBoundsException e) {
                    neighbors[q] = 'N';
                }
            }
            if (q == 1) {
                try {
                    neighbors[q] = map[x - 1][y];
                } catch (IndexOutOfBoundsException e) {
                    neighbors[q] = 'N';
                }
            }
            if (q == 2) {
                try {
                    neighbors[q] = map[x - 1][y + 1];
                } catch (IndexOutOfBoundsException e) {
                    neighbors[q] = 'N';
                }
            }
            if (q == 3) {
                try {
                    neighbors[q] = map[x][y + 1];
                } catch (IndexOutOfBoundsException e) {
                    neighbors[q] = 'N';
                }
            }
            if (q == 4) {
                try {
                    neighbors[q] = map[x + 1][y + 1];
                } catch (IndexOutOfBoundsException e) {
                    neighbors[q] = 'N';
                }
            }
            if (q == 5) {
                try {
                    neighbors[q] = map[x + 1][y];
                } catch (IndexOutOfBoundsException e) {
                    neighbors[q] = 'N';
                }
            }
            if (q == 6) {
                try {
                    neighbors[q] = map[x + 1][y - 1];
                } catch (IndexOutOfBoundsException e) {
                    neighbors[q] = 'N';
                }
            }
            if (q == 7) {
                try {
                    neighbors[q] = map[x][y - 1];
                } catch (IndexOutOfBoundsException e) {
                    neighbors[q] = 'N';
                }
            }
        }
        return neighbors;
    }

    /**
     * Prints map with all locations. Available for testing purposes.
     *
     * @param shown The map to be shown.
     */
    public void showMap(char[][] shown) {
        System.out.print("P  ");
        for (int q = 0; q < shown.length; q++) {
            System.out.print(q + "  ");
        }
        System.out.println();
        for (int q = 0; q < shown.length; q++) {
            System.out.print(q + "  ");
            for (int a = 0; a < shown.length; a++) {
                System.out.print(shown[q][a] + "  ");
            }
            System.out.println();
        }
    }

    /**
     * Returns the map array.
     * @return The 2-D character array representing the spaces on the map.
     */
    public char[][] getMap(){
        return map;
    }

    /**
     * Returns the shown square array.
     * @return The 2-D map of which squares are revealed or not.
     */
    public boolean[][] getShown(){
        return shown;
    }
}
