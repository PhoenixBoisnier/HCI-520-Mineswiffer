package com.phoenix;

import com.sun.tools.javac.Main;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.util.Objects;

public class CustRadioButtonPanel extends JPanel {

    private final JLabel minesCount;

    private JLabel redCircle = null;
    private JLabel bluCircle = null;
    private JLabel grnCircle = null;

    private int action;

    public static final int UNFLAG = 0;
    public static final int FLAG = 1;
    public static final int REVEAL = 2;

    /**
     * Creates a custom radio button panel for Mineswiffer-picker-upper.
     * When a button is selected, the panel repaints itself so that the selected button is more highlighted.
     * A red circle appears next to Reveal Square.
     * A blue circle appears next to
     */
    public CustRadioButtonPanel() {

        this.setLayout(new GridBagLayout());

        minesCount = new JLabel("MINES REMAINING: XX of YY");
        minesCount.repaint();
        minesCount.setVisible(true);
        GridBagConstraints countConst = new GridBagConstraints();
        countConst.gridx = 0;
        countConst.gridy = 0;
        countConst.insets = new Insets(5,5, 5,5);

        JButton reveal = new JButton("Reveal Square");
        reveal.setPreferredSize(new Dimension(185, 50));
        Point revlLoc = reveal.getLocation();
        revlLoc.setLocation(revlLoc.getX()+150, revlLoc.getY()+75);
        GridBagConstraints revlConst = new GridBagConstraints();
        revlConst.gridx = 0;
        revlConst.gridy = 2;
        revlConst.insets = new Insets(10,5,5,5);

        JButton flag = new JButton("Flag Square");
        flag.setPreferredSize(new Dimension(185, 50));
        Point flagLoc = flag.getLocation();
        flagLoc.setLocation(flagLoc.getX()+150, flagLoc.getY()+42);
        GridBagConstraints flagConst = new GridBagConstraints();
        flagConst.gridx = 0;
        flagConst.gridy = 4;
        flagConst.insets = new Insets(5,5,5,5);

        JButton question = new JButton("Remove Flag");
        question.setPreferredSize(new Dimension(185, 25));
        Point quesLoc = question.getLocation();
        quesLoc.setLocation(quesLoc.getX()+150, quesLoc.getY()+7);
        GridBagConstraints quesConst = new GridBagConstraints();
        quesConst.gridx = 0;
        quesConst.gridy = 3;
        quesConst.insets = new Insets(5,5,5,5);

        reveal.addActionListener(ActionEvent -> {
            action = CustRadioButtonPanel.REVEAL;
            redCircle.setVisible(true);
            bluCircle.setVisible(false);
            grnCircle.setVisible(false);
        });
        flag.addActionListener(ActionEvent -> {
            action = CustRadioButtonPanel.FLAG;
            grnCircle.setVisible(true);
            redCircle.setVisible(false);
            bluCircle.setVisible(false);
        });
        question.addActionListener(ActionEvent -> {
            action = CustRadioButtonPanel.UNFLAG;
            bluCircle.setVisible(true);
            grnCircle.setVisible(false);
            redCircle.setVisible(false);
        });

        ButtonGroup buttons = new ButtonGroup();
        buttons.add(question);
        buttons.add(flag);
        buttons.add(reveal);

        buttons.setSelected(reveal.getModel(), true);
        action = 2;

        reveal.setOpaque(false);
        flag.setOpaque(false);
        question.setOpaque(false);

        try {
            redCircle = new JLabel(new ImageIcon(ImageIO.read(Objects.requireNonNull(
                    Main.class.getClassLoader().getResource("red.png")))));
            bluCircle = new JLabel(new ImageIcon(ImageIO.read(Objects.requireNonNull(
                    Main.class.getClassLoader().getResource("yellow.png")))));
            grnCircle = new JLabel(new ImageIcon(ImageIO.read(Objects.requireNonNull(
                    Main.class.getClassLoader().getResource("blue.png")))));
        } catch (IOException e) {
            e.printStackTrace();
        }

        if(redCircle!=null&&bluCircle!=null&&grnCircle!=null){
            redCircle.setVisible(true);
            redCircle.setToolTipText("REVEAL SQUARE");
            GridBagConstraints redConst = new GridBagConstraints();
            redConst.gridx = 0;
            redConst.gridy = 1;
            redConst.insets = new Insets(0,0, 0,110);
            bluCircle.setVisible(false);
            bluCircle.setToolTipText("REMOVE FLAG");
            GridBagConstraints bluConst = new GridBagConstraints();
            bluConst.gridx = 0;
            bluConst.gridy = 1;
            bluConst.insets = new Insets(0,0, 0,0);
            grnCircle.setVisible(false);
            grnCircle.setToolTipText("FLAG SQUARE");
            GridBagConstraints grnConst = new GridBagConstraints();
            grnConst.gridx = 0;
            grnConst.gridy = 1;
            grnConst.insets = new Insets(0,110, 0,0);
            this.add(redCircle, redConst);
            this.add(grnCircle, grnConst);
            this.add(bluCircle, bluConst);
        }

        this.add(reveal, revlConst);
        this.add(flag, flagConst);
        this.add(question, quesConst);
        this.add(minesCount, countConst);

        this.setOpaque(true);
        this.setVisible(true);

    }

    public void updateMines(int m, int t){
        minesCount.setText("MINES REMAINING: "+m+" of "+t);
    }

    /**
     * Called by repaint this.repaint().
     * @param action Feed me this.getAction().
     */
    protected void buttonPress(int action){

        if(action == CustRadioButtonPanel.UNFLAG){
            bluCircle.setVisible(true);
            grnCircle.setVisible(false);
            redCircle.setVisible(false);
        }
        else if(action == CustRadioButtonPanel.FLAG){
            grnCircle.setVisible(true);
            redCircle.setVisible(false);
            bluCircle.setVisible(false);
        }
        else{
            redCircle.setVisible(true);
            bluCircle.setVisible(false);
            grnCircle.setVisible(false);
        }
        this.action = action;
    }

    /**
     * Returns the current selected action as an integer.
     * @return 0 == un-flag, 1 == flag, 2 == reveal, 3 == none selected; defaults to 3.
     */
    public int getAction(){
        return action;
    }
}
