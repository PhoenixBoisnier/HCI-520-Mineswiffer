package com.phoenix;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;

public class HowToPlay {

    public HowToPlay(){

        try {
            MinesweeperControlModel revealed = new MinesweeperControlModel(10, 5);
            GameGrid g = new GameGrid(revealed);
            g.cheaterAlert();
            g.cheating = false;
            g.cheatCount = 0;
            JLabel jl = new JLabel("<html>How to play:<br/>"+
                                        "1. Mine swiffer is a challenging game of logic and wit.<br/>" +
                                        "2. To play, you need to find and flag all of the mines without <br/>setting any off.<br/>" +
                                        "3. In order to find the mines, you must first reveal at least <br/>one square.<br/>" +
                                        "4. This is done by selecting the \"Reveal Square\" button in game,<br/> and selecting the square to reveal it.<br/>" +
                                        "5. If it was a mine, the game will end and you will lose.<br/>" +
                                        "6. If it was not a mine, it and nearby squares will be revealed,<br/> showing nothing or a number.<br/>" +
                                        "7. If a square has a number, be careful! That number tells you <br/>how many nearby mines there are nearby.<br/>" +
                                        "8. It should be noted that a nearby mine can be horizontal, <br/>vertical, or diagonal.<br/>" +
                                        "9. When you think you've found a mine, select the \"Flag Square\" <br/>button, and click a square to flag it.<br/>" +
                                        "10. Play continues until you reveal a mine or win.<br/>" +
                                        "11. When all of the squares with mines have a flag, you win!");
            g.add(jl);
            g.setPreferredSize(new Dimension(460, 550));
            g.pack();
            System.out.println(g.getComponent(0).getX());
            g.setVisible(true);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
