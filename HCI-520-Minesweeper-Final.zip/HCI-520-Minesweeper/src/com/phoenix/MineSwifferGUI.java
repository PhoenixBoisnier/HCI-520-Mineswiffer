package com.phoenix;

import javax.swing.*;

import static javax.swing.SwingUtilities.invokeLater;

public class MineSwifferGUI {

    public static void main(String[] args){

        ToolTipManager.sharedInstance().setInitialDelay(0);

        invokeLater(new PlantMinesAndStuff());
    }

}
