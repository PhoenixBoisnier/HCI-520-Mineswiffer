package com.phoenix;

public class PlantMinesAndStuff implements Runnable{

    public PlantMinesAndStuff(){

    }

    @Override
    public void run() {
        new HomeWindow();
    }
}
