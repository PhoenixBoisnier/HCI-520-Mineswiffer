package com.phoenix;

import com.sun.tools.javac.Main;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.Objects;

public class NewGameWindow extends JPanel{
    //TODO make this window prettier too.

    private final JPanel prev;

    /**
     * Creates a new game window on the preexisting window. Saves the previous panel for "back" functionality.
     * @param prevScreen The previous screen to return to.
     */
    public NewGameWindow(JPanel prevScreen){

        prev = prevScreen;
        this.setLayout(new GridBagLayout());

        JTextField size = new JTextField();
        size.setText("10");
        size.setToolTipText("Creates a square grid whose length is the value of this field. Must be 10 or more.");
        size.setPreferredSize(new Dimension(200, 25));
        GridBagConstraints sizeConst = new GridBagConstraints();
        sizeConst.gridx = 1;
        sizeConst.gridy = 0;
        sizeConst.insets = new Insets(5,5,5,5);
        JLabel sizeLabel = new JLabel("Size:");
        GridBagConstraints sLabelConst = new GridBagConstraints();
        sLabelConst.gridx = 0;
        sLabelConst.gridy = 0;
        sLabelConst.insets = new Insets(5,18,5,5);

        JTextField mines = new JTextField();
        mines.setText("10");
        mines.setToolTipText("Fills the grid with mines. Cannot exceed size squared.");
        mines.setPreferredSize(new Dimension(200,25));
        GridBagConstraints minesConst = new GridBagConstraints();
        minesConst.gridx = 1;
        minesConst.gridy = 1;
        minesConst.insets = new Insets(5,5,5,5);
        JLabel minesLabel = new JLabel("Mines:");
        GridBagConstraints mLabelConst = new GridBagConstraints();
        mLabelConst.gridx = 0;
        mLabelConst.gridy = 1;
        mLabelConst.insets = new Insets(5,5,5,5);

        JButton back = new JButton("Prev.");
        GridBagConstraints backConst = new GridBagConstraints();
        backConst.gridx = 0;
        backConst.gridy = 2;
        backConst.insets = new Insets(5,5,5,5);

        JButton startButton = new JButton("Begin Game!");
        startButton.setPreferredSize(new Dimension(200, 25));
        GridBagConstraints startConst = new GridBagConstraints();
        startConst.gridx = 1;
        startConst.gridy = 2;
        startConst.insets = new Insets(5,5,5,5);
        startButton.addActionListener(actionEvent -> startPressed(size.getText(), mines.getText()));
        startButton.setMnemonic(KeyEvent.VK_B);
        startButton.grabFocus();
        back.addActionListener(actionEvent -> backPressed());
        back.setMnemonic(KeyEvent.VK_P);

        this.add(sizeLabel, sLabelConst);
        this.add(size, sizeConst);
        this.add(minesLabel, mLabelConst);
        this.add(mines, minesConst);
        this.add(startButton, startConst);
        this.add(back, backConst);
        prevScreen.setVisible(false);
        this.setVisible(true);

    }

    /**
     * This method creates either a new game window or displays a popup window explaining an error.
     * @param size size of the game grid
     * @param mines number of mines in the game grid
     */
    private void startPressed(String size, String mines){
        MinesweeperControlModel mcm = null;
        try{
            if(Integer.parseInt(size)<10){
                try {
                    JOptionPane.showMessageDialog(this, "The options you have input are not valid.\n" +
                            "Size must be 10 or more.", "Improper input!", JOptionPane.ERROR_MESSAGE,
                            new ImageIcon(ImageIO.read(Objects.requireNonNull(
                                    Main.class.getClassLoader().getResource("errorIcon.png")))));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            else if(Integer.parseInt(mines)>Integer.parseInt(size)*Integer.parseInt(size)){
                try {
                    JOptionPane.showMessageDialog(this,"The options you have input are not valid.\n" +
                            "Mines must be less than Size squared.", "Improper input!", JOptionPane.ERROR_MESSAGE,
                            new ImageIcon(ImageIO.read(Objects.requireNonNull(
                                    Main.class.getClassLoader().getResource("errorIcon.png")))));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            else mcm = new MinesweeperControlModel(Integer.parseInt(size), Integer.parseInt(mines));
        } catch(NumberFormatException e){
            try {
                JOptionPane.showMessageDialog(this, "The options you have input are not valid.\n" +
                        "Input takes one positive integer for size and mines.", "Improper input!",
                        JOptionPane.ERROR_MESSAGE, new ImageIcon(ImageIO.read(Objects.requireNonNull(
                                Main.class.getClassLoader().getResource("errorIcon.png")))));
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
        }
        try{
            GameGrid game = new GameGrid(mcm);
            game.pack();
            game.setVisible(true);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (NullPointerException ignored){

        }
    }

    /**
     * KeyListeners are needy.
     */
    private void backPressed(){
        this.setVisible(false);
        prev.setVisible(true);
    }

}
