package com.phoenix;

import com.sun.tools.javac.Main;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.util.Objects;

public class GameGrid extends JFrame {

    private final FlaggingButton[][] buttonGrid;
    private final CustRadioButtonPanel playerAction;

    private MinesweeperControlModel mcm;
    private boolean[][] shownButtons;
    private int mineCount;

    protected boolean cheating = false;
    protected int cheatCount = 0;

    /**
     * Creates a playable game grid window.
     * @param data The initialized MinesweeperControlModel object.
     * @throws IOException FlaggingButton is the cause of this.
     */
    public GameGrid(MinesweeperControlModel data) throws IOException {
        mcm = data;
        mineCount = mcm.getMineCount();
        buttonGrid = new FlaggingButton[mcm.getMap().length][mcm.getMap().length];
        playerAction = new CustRadioButtonPanel();
        playerAction.setSize(playerAction.getSize());
        this.setTitle("Mine Swiffer Picker Upper");
        this.setLayout(new FlowLayout());
        this.setResizable(false);

        JPopupMenu modeSelect = new JPopupMenu();

        JMenuItem rsq = new JMenuItem("Reveal Square");
        rsq.setMnemonic('R');
        rsq.addActionListener(ActionEvent -> playerAction.buttonPress(CustRadioButtonPanel.REVEAL));
        modeSelect.add(rsq);

        JMenuItem rmf = new JMenuItem("Remove Flag");
        rmf.setMnemonic('D');
        rmf.addActionListener(ActionEvent -> playerAction.buttonPress(CustRadioButtonPanel.UNFLAG));
        modeSelect.add(rmf);

        JMenuItem fsq = new JMenuItem("Flag Square");
        fsq.setMnemonic('F');
        fsq.addActionListener(ActionEvent -> playerAction.buttonPress(CustRadioButtonPanel.FLAG));
        modeSelect.add(fsq);

        MouseAdapter mouseListens = new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                doTheThingPlease(e);
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                doTheThingPlease(e);
            }

            private void doTheThingPlease(MouseEvent e){
                if(e.isPopupTrigger()) {
                    modeSelect.show(e.getComponent(), e.getX(), e.getY());
                    modeSelect.setVisible(true);
                }
            }
        };
        this.addMouseListener(mouseListens);

        KeyListener keyboardListens = new KeyListener() {
            @Override
            public void keyTyped(KeyEvent keyEvent) {
                if(keyEvent.getKeyChar() == 'r'){
                    playerAction.buttonPress(CustRadioButtonPanel.REVEAL);
                }
                if(keyEvent.getKeyChar() == 'f'){
                    playerAction.buttonPress(CustRadioButtonPanel.FLAG);
                }
                if(keyEvent.getKeyChar() == 'd'){
                    playerAction.buttonPress(CustRadioButtonPanel.UNFLAG);
                }
                if(keyEvent.isAltDown()&&keyEvent.getKeyChar() == 'c'){
                    cheaterAlert();
                }
            }
            @Override
            public void keyPressed(KeyEvent keyEvent) {
            }
            @Override
            public void keyReleased(KeyEvent keyEvent) {
            }
        };
        this.addKeyListener(keyboardListens);

        shownButtons = mcm.getShown();

        GridLayout buttonGridLayout = new GridLayout(mcm.getMap().length, mcm.getMap().length);
        JPanel buttonGridPanel = new JPanel(buttonGridLayout);
        buttonGridPanel.setOpaque(false);
        buttonGridPanel.setPreferredSize(new Dimension(25*mcm.getMap().length, 25*mcm.getMap().length));
        for(int q = 0; q < mcm.getMap().length; q++){
            for(int w = 0; w < mcm.getMap().length; w++){
                final int qX = q;
                final int wY = w;
                buttonGrid[q][w] = new FlaggingButton(mcm.getMap()[q][w]);
                int BUTTON_SIZE = 20;
                buttonGrid[q][w].setSize(BUTTON_SIZE, BUTTON_SIZE);
                buttonGrid[q][w].addActionListener(press -> pressSquare(buttonGrid[qX][wY], qX, wY));
                buttonGrid[q][w].addMouseListener(mouseListens);
                buttonGrid[q][w].addKeyListener(keyboardListens);
                buttonGridPanel.add(buttonGrid[q][w]);
            }
        }
        this.add(buttonGridPanel);

        playerAction.updateMines(mcm.getMineCount(), mcm.getMineTotal());
        playerAction.addKeyListener(keyboardListens);
        this.add(playerAction);
    }

    /**
     * Handles button pressing in the grid.
     * @param button The button being pressed, which holds info about its flag state.
     * @param xS x-coordinate of the selected button.
     * @param yS y-coordinate of the selected button.
     */
    private void pressSquare(FlaggingButton button, int xS, int yS){
        this.setLayout(null);
        switch(playerAction.getAction()){
            case 0:{
                //UN-FLAGs button.
                if(button.isFlagged()){
                    button.toggleFlag();
                    if(mcm.getMap()[xS][yS]=='M'){
                        mcm.incMineCount();
                    }
                    mineCount++;
                    playerAction.updateMines(mineCount, mcm.getMineTotal());
                }
                break;
            }
            case 1:{
                if(mineCount==0){
                    try {
                        JOptionPane.showMessageDialog(this,
                                "You have planted all the flags you have.\n" +
                                        "You must remove preexisting flags to plant more.", "Oh no!",
                                JOptionPane.INFORMATION_MESSAGE, new ImageIcon(ImageIO.read(Objects.requireNonNull(
                                        Main.class.getClassLoader().getResource("errorIcon.png")))));
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                //FLAGs button.
                if(!button.isFlagged()&&mineCount>0){
                    button.toggleFlag();
                    mcm.getShown()[xS][yS] = false;
                    if(mcm.getMap()[xS][yS]=='M'){
                        mcm.decMineCount();
                    }
                    mineCount--;
                    playerAction.updateMines(mineCount, mcm.getMineTotal());
                }
                break;
            }
            case 2:{
                //REVEALs the space under the button.
                if(!button.isFlagged()){
                    try {
                        mcm = new MapUpdater(mcm, xS, yS).doInBackground();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    //mcm.revealSquare(xS, yS);
                    shownButtons = mcm.getShown();
                    for(int q = 0; q < mcm.getMap().length; q++){
                        for(int w = 0; w < mcm.getMap().length; w++){
                            if(shownButtons[q][w]){
                                if(buttonGrid[q][w].isFlagged()){
                                    mineCount++;
                                    buttonGrid[q][w].toggleFlag();
                                }
                                buttonGrid[q][w].setVisible(false);
                                drawIcon(buttonGrid[q][w]);
                                if(mcm.getMap()[q][w]=='M'){
                                    loser();
                                    try {
                                        JOptionPane.showMessageDialog(this,
                                                "You may close the game window at any time.", "LOSER!",
                                                JOptionPane.INFORMATION_MESSAGE,
                                                new ImageIcon(ImageIO.read(Objects.requireNonNull(
                                                        Main.class.getClassLoader().getResource(
                                                                "explosionIcon.png")))));
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }
                                }
                            }
                        }
                    }
                    playerAction.updateMines(mineCount, mcm.getMineTotal());
                }
                break;
            }
            default:{
                JOptionPane.showMessageDialog(
                        this, "There has been a critical error, the game will now exit.");
                this.dispose();
                break;
            }
        }
        if(mcm.getMineCount() == 0 && mineCount == 0){
            if(cheatCount==0){
                try {
                    JOptionPane.showMessageDialog(this,
                            "You're so amazing, you did it!\n", "WINNER!",
                            JOptionPane.INFORMATION_MESSAGE, new ImageIcon(ImageIO.read(Objects.requireNonNull(
                                    Main.class.getClassLoader().getResource("trophyIcon.png")))));
                    this.dispose();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            else{
                try {
                    for(int q = cheatCount; q > 0; q--){
                        JOptionPane.showMessageDialog(this,
                                ((q-1)>0)?"Did you think I wouldn't notice?\n" +
                                        "You cheated buddy. You have "+(q-1)+" more popups.":
                                        "Did you think I wouldn't notice?\nYou cheated buddy.", "\"winner...\"",
                                JOptionPane.INFORMATION_MESSAGE, new ImageIcon(ImageIO.read(Objects.requireNonNull(
                                        Main.class.getClassLoader().getResource("your-did-it.jpg")))));
                    }
                    this.dispose();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }

    /**
     * Grabs the image to be drawn from the appropriate button in the grid.
     */
    private void drawIcon(FlaggingButton b) {
        b.getRevealedIcon().setBounds(b.getX()+7,b.getY()+7,20,20);
        this.setLayout(null);
        this.add(b.getRevealedIcon());
    }

    /**
     * Reveals all the squares.
     */
    private void loser(){
        for(int q = 0; q < mcm.getMap().length; q++){
            for(int w = 0; w < mcm.getMap().length; w++){
                buttonGrid[q][w].setVisible(false);
                drawIcon(buttonGrid[q][w]);
            }
        }
        mineCount = 0;
        playerAction.updateMines(mineCount, mcm.getMineTotal());
    }

    /**
     * This is for cheaters. You're not trying to cheat at Mine Swiffer(TM), are you?
     */
    protected void cheaterAlert(){
        if(!cheating) cheatCount++;
        cheating = !cheating;

        for(int q = 0; q < mcm.getMap().length; q++){
            for(int w = 0; w < mcm.getMap().length; w++){
                if(cheating&&mcm.getMap()[q][w]=='M'){
                    ToolTipManager.sharedInstance().registerComponent(buttonGrid[q][w]);
                    buttonGrid[q][w].setToolTipText("There is a mine here.");
                }
                else{
                    ToolTipManager.sharedInstance().unregisterComponent(buttonGrid[q][w]);
                }
            }
        }
    }

}
